import os

def path():
    re = os.path.abspath(__file__)
    return re